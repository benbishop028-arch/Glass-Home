# Activity and accessibility service are kept automatically via the manifest.
