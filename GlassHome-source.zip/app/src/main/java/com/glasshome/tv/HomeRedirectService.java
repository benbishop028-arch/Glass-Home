package com.glasshome.tv;

import android.accessibilityservice.AccessibilityService;
import android.app.ActivityOptions;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Fire OS won't let another app be the default home screen, so this service watches for the
 * Amazon home screen coming up after the Home or Back button (or at start-up) and opens Glass Home
 * on top of it. It never blocks or changes a key press, so long-press Home (quick settings),
 * the Alexa button and everything else work as normal. Alexa results opened by voice are left alone.
 */
public class HomeRedirectService extends AccessibilityService {

    private static final long KEY_WINDOW_MS = 4000;
    private static final long BOOT_WINDOW_MS = 90_000;

    /** While set, the Amazon home screen is left alone (used by the "Amazon Home" tile). */
    static volatile long pauseUntil;

    private long connectedAt;
    private long lastKeyAt;
    private int lastKey;
    private boolean anyKeySeen;

    static void pause(long ms) {
        pauseUntil = SystemClock.uptimeMillis() + ms;
    }

    static boolean isEnabled(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(s)) return false;
        String me = new ComponentName(c, HomeRedirectService.class).flattenToString();
        String meShort = new ComponentName(c, HomeRedirectService.class).flattenToShortString();
        for (String part : s.split(":")) {
            if (part.equalsIgnoreCase(me) || part.equalsIgnoreCase(meShort)) return true;
        }
        return false;
    }

    @Override
    protected void onServiceConnected() {
        connectedAt = SystemClock.uptimeMillis();
        // If the stick has just booted onto the Amazon home screen, replace it now.
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                CharSequence pkg = root.getPackageName();
                if (pkg != null && Apps.AMAZON_LAUNCHER.contentEquals(pkg)) openGlassHome();
            }
        } catch (Exception ignored) { }
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_UP) {
            anyKeySeen = true;
            lastKey = event.getKeyCode();
            lastKeyAt = SystemClock.uptimeMillis();
            if (lastKey == KeyEvent.KEYCODE_HOME) pauseUntil = 0;   // Home always means Glass Home
        }
        return false;   // never swallow a key
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkg = e.getPackageName();
        CharSequence cls = e.getClassName();
        if (pkg == null || cls == null) return;
        if (!Apps.AMAZON_LAUNCHER.contentEquals(pkg)) return;
        if (!cls.toString().contains("HomeActivity")) return;   // only the home screen itself

        long now = SystemClock.uptimeMillis();
        if (now < pauseUntil) return;

        boolean recentKey = now - lastKeyAt < KEY_WINDOW_MS;
        boolean viaHome = recentKey && lastKey == KeyEvent.KEYCODE_HOME;
        boolean viaBack = recentKey && (lastKey == KeyEvent.KEYCODE_BACK || lastKey == KeyEvent.KEYCODE_ESCAPE);
        boolean startup = !anyKeySeen && now - connectedAt < BOOT_WINDOW_MS;
        // Some remotes' Home presses never reach accessibility; if we have never seen any key at all,
        // treat every Amazon home screen as a Home press.
        boolean noKeyReporting = !anyKeySeen && now - connectedAt >= BOOT_WINDOW_MS;

        if (viaHome || viaBack || startup || noKeyReporting) openGlassHome();
    }

    private void openGlassHome() {
        Intent i = new Intent(this, HomeActivity.class)
                .setAction(Intent.ACTION_MAIN)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                        | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        try {
            startActivity(i, ActivityOptions.makeCustomAnimation(this, 0, 0).toBundle());
        } catch (Exception ignored) { }
    }

    @Override
    public void onInterrupt() { }
}
