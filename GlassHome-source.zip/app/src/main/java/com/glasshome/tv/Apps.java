package com.glasshome.tv;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Launchable apps and the dock order. Everything here is safe to call off the main thread. */
final class Apps {

    static final String AMAZON_LAUNCHER = "com.amazon.tv.launcher";

    /** The user's chosen dock, in order. Apps that aren't installed are simply skipped. */
    static final String[] DEFAULT_DOCK = {
            "com.debridstream.tv",
            "com.amazon.firetv.youtube",
            "com.netflix.ninja",
            "com.amazon.firebat",          // Prime Video
            "com.disney.disneyplus",
            "com.stremio.one",
            "com.esaba.downloader",
    };

    static final class Entry {
        final String pkg;
        final String label;
        final ResolveInfo info;
        Drawable banner;   // loaded lazily
        Drawable icon;
        boolean art;       // true once banner/icon have been loaded

        Entry(String pkg, String label, ResolveInfo info) {
            this.pkg = pkg;
            this.label = label;
            this.info = info;
        }
    }

    private final Context ctx;
    private final PackageManager pm;
    private final SharedPreferences prefs;

    Apps(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.pm = this.ctx.getPackageManager();
        this.prefs = this.ctx.getSharedPreferences("glasshome", Context.MODE_PRIVATE);
    }

    /** All launchable apps (TV launcher entries preferred), sorted by name, excluding ourselves. */
    List<Entry> loadAll() {
        Map<String, Entry> byPkg = new LinkedHashMap<>();
        collect(byPkg, Intent.CATEGORY_LEANBACK_LAUNCHER);
        collect(byPkg, Intent.CATEGORY_LAUNCHER);
        byPkg.remove(ctx.getPackageName());
        byPkg.remove(AMAZON_LAUNCHER);
        List<Entry> list = new ArrayList<>(byPkg.values());
        final Collator col = Collator.getInstance();
        Collections.sort(list, (a, b) -> col.compare(a.label, b.label));
        return list;
    }

    private void collect(Map<String, Entry> out, String category) {
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(category);
        List<ResolveInfo> res;
        try {
            res = pm.queryIntentActivities(i, 0);
        } catch (RuntimeException e) {
            return;
        }
        for (ResolveInfo ri : res) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (out.containsKey(pkg)) continue;
            ApplicationInfo ai = ri.activityInfo.applicationInfo;
            if (ai != null && !ai.enabled) continue;
            CharSequence l = ri.loadLabel(pm);
            out.put(pkg, new Entry(pkg, l == null ? pkg : l.toString().trim(), ri));
        }
    }

    /** Loads banner (TV 16:9 artwork) and icon. Call off the main thread. */
    void loadArt(Entry e) {
        if (e.art) return;
        Drawable banner = null, icon = null;
        try {
            banner = e.info.activityInfo.loadBanner(pm);
            if (banner == null) banner = pm.getApplicationBanner(e.pkg);
        } catch (Exception ignored) { }
        try {
            icon = e.info.loadIcon(pm);
        } catch (Exception ignored) { }
        e.banner = banner;
        e.icon = icon;
        e.art = true;
    }

    Intent launchIntent(String pkg) {
        Intent i = null;
        try {
            i = pm.getLeanbackLaunchIntentForPackage(pkg);
            if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        } catch (Exception ignored) { }
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        }
        return i;
    }

    // ------------------------------------------------------------------ dock order

    List<String> dock() {
        String s = prefs.getString("dock", null);
        if (s == null) return new ArrayList<>(Arrays.asList(DEFAULT_DOCK));
        List<String> out = new ArrayList<>();
        if (!s.isEmpty()) out.addAll(Arrays.asList(s.split(",")));
        return out;
    }

    void saveDock(List<String> dock) {
        prefs.edit().putString("dock", TextUtils.join(",", dock)).apply();
    }

    boolean inDock(String pkg) {
        return dock().contains(pkg);
    }

    void toggleDock(String pkg) {
        List<String> d = dock();
        if (!d.remove(pkg)) d.add(pkg);
        saveDock(d);
    }
}
