package com.glasshome.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Apple TV-style home screen: full-screen nature photo, clock, and a dock of favourite apps.
 * Down (or the "All Apps" tile) opens every app; Menu or a long press on any tile edits the dock.
 * Built from plain framework views (no libraries) to keep it light on a 1.7 GB Fire Stick.
 */
public class HomeActivity extends Activity implements Walls.Sink {

    private static final int GRID_COLUMNS = 5;
    private static final String TILE_ALL_APPS = "#all";
    private static final String TILE_SETTINGS = "#settings";
    private static final String TILE_AMAZON = "#amazon";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();   // apps + art
    private final ExecutorService wallBg = Executors.newSingleThreadExecutor(); // photos (own thread so a slow download never delays icons)

    private Apps apps;
    private Walls walls;

    private FrameLayout root;
    private ImageView wallLower, wallUpper;
    private boolean upperShowing;
    private TextView clock, date, caption, focusLabel, notice;
    private HorizontalScrollView dockScroll;
    private LinearLayout dockRow;
    private FrameLayout overlay;
    private ScrollView gridScroll;
    private GridLayout grid;

    private List<Apps.Entry> allApps = new ArrayList<>();
    private final Map<String, Apps.Entry> byPkg = new HashMap<>();
    private String lastDockFocus;
    private boolean receiversOn;
    private int loadGen;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        apps = new Apps(this);
        walls = new Walls(this, wallBg, ui, this);
        buildUi();
        IntentFilter pf = new IntentFilter();
        pf.addAction(Intent.ACTION_PACKAGE_ADDED);
        pf.addAction(Intent.ACTION_PACKAGE_REMOVED);
        pf.addAction(Intent.ACTION_PACKAGE_CHANGED);
        pf.addDataScheme("package");
        registerReceiver(packages, pf);
        loadApps();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter tf = new IntentFilter();
        tf.addAction(Intent.ACTION_TIME_TICK);
        tf.addAction(Intent.ACTION_TIME_CHANGED);
        tf.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        registerReceiver(timeTick, tf);
        receiversOn = true;
        updateClock();
        updateNotice();
        walls.start(wallUpper.getDrawable() != null || wallLower.getDrawable() != null);
    }

    @Override
    protected void onStop() {
        super.onStop();
        walls.stop();
        if (receiversOn) {
            unregisterReceiver(timeTick);
            receiversOn = false;
        }
        // The hidden photo layer isn't needed while an app is playing; give the memory back.
        (upperShowing ? wallLower : wallUpper).setImageDrawable(null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(packages); } catch (Exception ignored) { }
        bg.shutdownNow();
        wallBg.shutdownNow();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) {
            // We're behind a video app and memory is short: drop the photo and app artwork.
            wallUpper.setImageDrawable(null);
            wallLower.setImageDrawable(null);
            closeOverlay(false);
            grid.removeAllViews();
            for (Apps.Entry e : allApps) {
                e.banner = null;
                e.icon = null;
                e.art = false;
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        closeOverlay(false);
        focusDock(lastDockFocus);
    }

    @Override
    public void onBackPressed() {
        if (overlay.getVisibility() == View.VISIBLE) closeOverlay(true);
        // otherwise stay on the home screen
    }

    private final BroadcastReceiver timeTick = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { updateClock(); }
    };

    private final BroadcastReceiver packages = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            ui.removeCallbacks(reload);
            ui.postDelayed(reload, 1500);
        }
    };

    private final Runnable reload = this::loadApps;

    // ------------------------------------------------------------------ building the screen

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setClipChildren(false);

        // Fallback background until the first photo arrives (and when offline with an empty cache).
        GradientDrawable night = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF1B3A4B, 0xFF0E1E2A, 0xFF05090D});
        root.setBackground(night);

        wallLower = photoView();
        wallUpper = photoView();
        root.addView(wallLower, match());
        root.addView(wallUpper, match());

        View scrim = new View(this);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x66000000, 0x00000000, 0x00000000, 0x33000000, 0xCC000000}));
        root.addView(scrim, match());

        // Clock (top right)
        LinearLayout clockBox = new LinearLayout(this);
        clockBox.setOrientation(LinearLayout.VERTICAL);
        clockBox.setGravity(Gravity.END);
        clock = text(46, Typeface.create("sans-serif-light", Typeface.NORMAL), 0xFFFFFFFF);
        date = text(15, Typeface.create("sans-serif", Typeface.NORMAL), 0xDDFFFFFF);
        notice = text(12, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0xFFFFC266);
        notice.setVisibility(View.GONE);
        clockBox.addView(clock);
        clockBox.addView(date);
        clockBox.addView(notice);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        clp.setMargins(0, dp(28), dp(48), 0);
        root.addView(clockBox, clp);

        // Photo credit (top left)
        caption = text(11, Typeface.create("sans-serif", Typeface.NORMAL), 0xB3FFFFFF);
        caption.setMaxLines(1);
        caption.setEllipsize(TextUtils.TruncateAt.END);
        FrameLayout.LayoutParams cap = new FrameLayout.LayoutParams(dp(520), -2, Gravity.TOP | Gravity.START);
        cap.setMargins(dp(48), dp(34), 0, 0);
        root.addView(caption, cap);

        // Dock
        dockScroll = new HorizontalScrollView(this);
        dockScroll.setHorizontalScrollBarEnabled(false);
        dockScroll.setFillViewport(false);
        dockScroll.setClipChildren(false);
        dockScroll.setClipToPadding(false);
        dockScroll.setSmoothScrollingEnabled(true);
        dockRow = new LinearLayout(this);
        dockRow.setOrientation(LinearLayout.HORIZONTAL);
        dockRow.setClipChildren(false);
        dockRow.setClipToPadding(false);
        dockRow.setPadding(dp(48), dp(22), dp(48), dp(22));
        dockScroll.addView(dockRow, new FrameLayout.LayoutParams(-2, -2));
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        dlp.bottomMargin = dp(46);
        root.addView(dockScroll, dlp);

        focusLabel = text(15, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0xFFFFFFFF);
        focusLabel.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        flp.bottomMargin = dp(20);
        root.addView(focusLabel, flp);

        // All-apps overlay
        overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0xE60B0D10);
        overlay.setVisibility(View.GONE);
        overlay.setClipChildren(false);
        TextView title = text(24, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0xFFFFFFFF);
        title.setText("All Apps");
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        tlp.setMargins(dp(56), dp(28), 0, 0);
        overlay.addView(title, tlp);
        TextView hint = text(12, Typeface.create("sans-serif", Typeface.NORMAL), 0x99FFFFFF);
        hint.setText("Press Menu or hold Select on an app to add it to the dock");
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        hlp.setMargins(0, dp(38), dp(56), 0);
        overlay.addView(hint, hlp);
        gridScroll = new ScrollView(this);
        gridScroll.setVerticalScrollBarEnabled(false);
        gridScroll.setClipChildren(false);
        gridScroll.setClipToPadding(false);
        gridScroll.setPadding(0, dp(12), 0, dp(40));
        grid = new GridLayout(this);
        grid.setColumnCount(GRID_COLUMNS);
        grid.setClipChildren(false);
        grid.setClipToPadding(false);
        gridScroll.addView(grid, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL));
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(-1, -1);
        glp.topMargin = dp(72);
        overlay.addView(gridScroll, glp);
        root.addView(overlay, match());

        setContentView(root);
    }

    private ImageView photoView() {
        ImageView v = new ImageView(this);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setAlpha(0f);
        return v;
    }

    // ------------------------------------------------------------------ apps

    private void loadApps() {
        final int gen = ++loadGen;
        bg.execute(() -> {
            List<Apps.Entry> list = apps.loadAll();
            // Artwork for dock apps first so the dock fills in quickly.
            Map<String, Apps.Entry> map = new HashMap<>();
            for (Apps.Entry e : list) map.put(e.pkg, e);
            for (String p : apps.dock()) {
                Apps.Entry e = map.get(p);
                if (e != null) apps.loadArt(e);
            }
            ui.post(() -> {
                if (gen != loadGen || isDestroyed()) return;
                allApps = list;
                byPkg.clear();
                byPkg.putAll(map);
                buildDock();
                if (overlay.getVisibility() == View.VISIBLE) buildGrid();
                else grid.removeAllViews();
            });
        });
    }

    private List<String> visibleDock() {
        List<String> out = new ArrayList<>();
        for (String p : apps.dock()) if (byPkg.containsKey(p)) out.add(p);
        return out;
    }

    private void buildDock() {
        String keep = lastDockFocus;
        boolean hadFocus = dockRow.hasFocus() || getCurrentFocus() == null;
        dockRow.removeAllViews();
        for (String p : visibleDock()) {
            Apps.Entry e = byPkg.get(p);
            dockRow.addView(appTile(e, true));
        }
        dockRow.addView(actionTile(TILE_ALL_APPS, "All Apps", true));
        dockRow.addView(actionTile(TILE_SETTINGS, "Settings", true));
        if (hadFocus && overlay.getVisibility() != View.VISIBLE) focusDock(keep);
    }

    private void focusDock(String tag) {
        ui.post(() -> {
            View target = null;
            if (tag != null) target = dockRow.findViewWithTag(tag);
            if (target == null && dockRow.getChildCount() > 0) target = dockRow.getChildAt(0);
            if (target != null) target.requestFocus();
        });
    }

    private void buildGrid() {
        grid.removeAllViews();
        grid.addView(actionTile(TILE_AMAZON, "Amazon Home", false));
        grid.addView(actionTile(TILE_SETTINGS, "Settings", false));
        for (Apps.Entry e : allApps) grid.addView(appTile(e, false));
        // Load the remaining artwork in the background, a few at a time.
        final List<Apps.Entry> todo = new ArrayList<>();
        for (Apps.Entry e : allApps) if (!e.art) todo.add(e);
        final int gen = loadGen;
        bg.execute(() -> {
            for (Apps.Entry e : todo) {
                if (gen != loadGen) return;
                apps.loadArt(e);
                ui.post(() -> {
                    if (gen != loadGen) return;
                    View v = grid.findViewWithTag(e.pkg);
                    if (v instanceof FrameLayout) fillArt((FrameLayout) v, e);
                });
            }
        });
    }

    // ------------------------------------------------------------------ tiles

    private FrameLayout baseTile(String tag, boolean dock) {
        int w = dp(dock ? 160 : 150), h = dp(dock ? 90 : 84);
        FrameLayout t = new FrameLayout(this);
        t.setTag(tag);
        t.setFocusable(true);
        t.setClickable(true);
        t.setLongClickable(true);
        final int r = dp(10);
        t.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), r);
            }
        });
        t.setClipToOutline(true);
        t.setElevation(dp(3));
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(0x33FFFFFF);
        t.setBackground(bgd);
        if (dock) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
            lp.setMargins(dp(11), 0, dp(11), 0);
            t.setLayoutParams(lp);
        } else {
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = w;
            lp.height = h;
            lp.setMargins(dp(12), dp(12), dp(12), dp(12));
            t.setLayoutParams(lp);
        }
        final GradientDrawable ring = new GradientDrawable();
        ring.setCornerRadius(r);
        ring.setStroke(dp(2), 0xE6FFFFFF);
        ring.setColor(Color.TRANSPARENT);
        t.setOnFocusChangeListener((v, has) -> {
            v.animate().scaleX(has ? 1.12f : 1f).scaleY(has ? 1.12f : 1f)
                    .translationZ(has ? dp(14) : 0).setDuration(140).start();
            ((FrameLayout) v).setForeground(has ? ring : null);
            if (has) {
                CharSequence label = v.getContentDescription();
                focusLabel.setText(label == null ? "" : label);
                if (dock) lastDockFocus = (String) v.getTag();
            }
        });
        return t;
    }

    private FrameLayout appTile(Apps.Entry e, boolean dock) {
        FrameLayout t = baseTile(e.pkg, dock);
        t.setContentDescription(e.label);
        fillArt(t, e);
        t.setOnClickListener(v -> launch(e.pkg));
        t.setOnLongClickListener(v -> { showOptions(e, dock); return true; });
        t.setOnKeyListener((v, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (code == KeyEvent.KEYCODE_MENU) { showOptions(e, dock); return true; }
            return navKey(v, code, dock);
        });
        return t;
    }

    private void fillArt(FrameLayout t, Apps.Entry e) {
        t.removeAllViews();
        if (e.banner != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageDrawable(e.banner);
            t.addView(iv, match());
            return;
        }
        // No TV banner: icon and name on a soft glass tile.
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        if (e.icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(e.icon);
            box.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
        }
        TextView tv = text(12, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0xFFFFFFFF);
        tv.setText(e.label);
        tv.setMaxLines(1);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(8), dp(6), dp(8), 0);
        box.addView(tv, new LinearLayout.LayoutParams(-1, -2));
        t.addView(box, match());
    }

    private FrameLayout actionTile(String tag, String label, boolean dock) {
        FrameLayout t = baseTile(tag, dock);
        t.setContentDescription(label);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.addView(actionIcon(tag), new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView l = text(13, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0xFFFFFFFF);
        l.setText(label);
        l.setGravity(Gravity.CENTER);
        l.setPadding(0, dp(8), 0, 0);
        box.addView(l);
        t.addView(box, match());
        t.setOnClickListener(v -> onAction(tag));
        t.setOnKeyListener((v, code, ev) ->
                ev.getAction() == KeyEvent.ACTION_DOWN && navKey(v, code, dock));
        return t;
    }

    /** Settings and Amazon Home use the system's own icons; All Apps is a drawn 3x3 grid. */
    private View actionIcon(String tag) {
        Drawable d = null;
        try {
            Intent i = TILE_SETTINGS.equals(tag) ? new Intent(Settings.ACTION_SETTINGS)
                    : TILE_AMAZON.equals(tag) ? new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setPackage(Apps.AMAZON_LAUNCHER)
                    : null;
            if (i != null) {
                android.content.pm.ResolveInfo ri = getPackageManager().resolveActivity(i, 0);
                if (ri != null) d = ri.loadIcon(getPackageManager());
            }
        } catch (Exception ignored) { }
        if (d != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(d);
            return iv;
        }
        GridLayout g = new GridLayout(this);
        g.setColumnCount(3);
        int cell = dp(8), gap = dp(1);
        for (int k = 0; k < 9; k++) {
            View dot = new View(this);
            GradientDrawable sq = new GradientDrawable();
            sq.setCornerRadius(dp(2));
            sq.setColor(0xFFFFFFFF);
            dot.setBackground(sq);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cell;
            lp.height = cell;
            lp.setMargins(gap, gap, gap, gap);
            g.addView(dot, lp);
        }
        return g;
    }

    /** Down from the dock opens All Apps; Up from the top row of All Apps closes it. */
    private boolean navKey(View v, int code, boolean dock) {
        if (dock && code == KeyEvent.KEYCODE_DPAD_DOWN) {
            openOverlay();
            return true;
        }
        if (!dock && code == KeyEvent.KEYCODE_DPAD_UP) {
            int idx = grid.indexOfChild(v);
            if (idx >= 0 && idx < GRID_COLUMNS) {
                closeOverlay(true);
                return true;
            }
        }
        return false;
    }

    private void onAction(String tag) {
        switch (tag) {
            case TILE_ALL_APPS:
                openOverlay();
                break;
            case TILE_SETTINGS:
                start(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                break;
            case TILE_AMAZON:
                HomeRedirectService.pause(10 * 60 * 1000L);
                Toast.makeText(this, "Amazon Home – press Home to come back", Toast.LENGTH_SHORT).show();
                start(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                        .setPackage(Apps.AMAZON_LAUNCHER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                break;
            default:
                break;
        }
    }

    private void launch(String pkg) {
        Intent i = apps.launchIntent(pkg);
        if (i == null) {
            Toast.makeText(this, "Can't open that app", Toast.LENGTH_SHORT).show();
            return;
        }
        start(i);
    }

    private void start(Intent i) {
        try {
            startActivity(i);
        } catch (ActivityNotFoundException | SecurityException ex) {
            Toast.makeText(this, "Can't open that", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------ editing the dock

    private void showOptions(Apps.Entry e, boolean fromDock) {
        final List<String> dock = visibleDock();
        final boolean inDock = dock.contains(e.pkg);
        final List<String> labels = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();
        if (inDock) {
            final int idx = dock.indexOf(e.pkg);
            if (idx > 0) {
                labels.add("Move left");
                actions.add(() -> moveInDock(e.pkg, -1));
            }
            if (idx < dock.size() - 1) {
                labels.add("Move right");
                actions.add(() -> moveInDock(e.pkg, 1));
            }
            labels.add("Remove from dock");
            actions.add(() -> { apps.toggleDock(e.pkg); buildDock(); toast("Removed from dock"); });
        } else {
            labels.add("Add to dock");
            actions.add(() -> { apps.toggleDock(e.pkg); buildDock(); toast("Added to dock"); });
        }
        labels.add("App info");
        actions.add(() -> start(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", e.pkg, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(e.label)
                .setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run())
                .show();
    }

    private void moveInDock(String pkg, int delta) {
        List<String> visible = visibleDock();
        int i = visible.indexOf(pkg), j = i + delta;
        if (i < 0 || j < 0 || j >= visible.size()) return;
        visible.set(i, visible.get(j));
        visible.set(j, pkg);
        // Keep dock entries for apps that aren't installed right now, after the visible ones.
        List<String> all = new ArrayList<>(visible);
        for (String p : apps.dock()) if (!all.contains(p)) all.add(p);
        apps.saveDock(all);
        lastDockFocus = pkg;
        buildDock();
        focusDock(pkg);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ overlay

    private void openOverlay() {
        if (overlay.getVisibility() == View.VISIBLE) return;
        if (grid.getChildCount() == 0) buildGrid();
        overlay.setAlpha(0f);
        overlay.setVisibility(View.VISIBLE);
        overlay.animate().alpha(1f).setDuration(160).start();
        dockScroll.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        gridScroll.scrollTo(0, 0);
        ui.post(() -> {
            View first = grid.getChildCount() > 2 ? grid.getChildAt(2) : grid.getChildAt(0);
            if (first != null) first.requestFocus();
        });
    }

    private void closeOverlay(boolean animate) {
        if (overlay.getVisibility() != View.VISIBLE) return;
        dockScroll.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        if (animate) {
            overlay.animate().alpha(0f).setDuration(140).withEndAction(() -> overlay.setVisibility(View.GONE)).start();
        } else {
            overlay.animate().cancel();
            overlay.setVisibility(View.GONE);
        }
        focusDock(lastDockFocus);
    }

    // ------------------------------------------------------------------ wallpaper + clock

    @Override
    public void showWallpaper(Bitmap bmp, String text) {
        // Cross-fade: put the new photo on whichever layer is hidden, then fade between them.
        final ImageView incoming = upperShowing ? wallLower : wallUpper;
        final ImageView outgoing = upperShowing ? wallUpper : wallLower;
        incoming.animate().cancel();
        outgoing.animate().cancel();
        incoming.setImageBitmap(bmp);
        if (incoming == wallUpper) {
            outgoing.setAlpha(1f);
            incoming.setAlpha(0f);
            incoming.animate().alpha(1f).setDuration(1200)
                    .withEndAction(() -> outgoing.setImageDrawable(null)).start();
        } else {
            incoming.setAlpha(1f);
            outgoing.animate().alpha(0f).setDuration(1200)
                    .withEndAction(() -> outgoing.setImageDrawable(null)).start();
        }
        upperShowing = incoming == wallUpper;
        caption.animate().cancel();
        caption.animate().alpha(0f).setDuration(300).withEndAction(() -> {
            caption.setText(text == null ? "" : text);
            caption.animate().alpha(1f).setDuration(500).start();
        }).start();
    }

    private void updateClock() {
        Date now = new Date();
        clock.setText(DateFormat.getTimeFormat(this).format(now));
        date.setText(new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now));
    }

    private void updateNotice() {
        if (HomeRedirectService.isEnabled(this)) {
            notice.setVisibility(View.GONE);
        } else {
            notice.setText("Home button redirect is off");
            notice.setVisibility(View.VISIBLE);
        }
    }

    // ------------------------------------------------------------------ helpers

    private TextView text(float sp, Typeface tf, int color) {
        TextView t = new TextView(this);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTypeface(tf);
        t.setTextColor(color);
        t.setShadowLayer(dp(4), 0, dp(1), 0x99000000);
        t.setIncludeFontPadding(false);
        return t;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static FrameLayout.LayoutParams match() {
        return new FrameLayout.LayoutParams(-1, -1);
    }
}
