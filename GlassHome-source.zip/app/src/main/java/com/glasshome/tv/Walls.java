package com.glasshome.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.text.Html;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;

/**
 * Rotating nature wallpapers from Wikimedia Commons featured pictures (free licences, credited on screen).
 * Photos are cached on the stick so it keeps rotating offline. Only one decode/download runs at a time,
 * and nothing runs while another app is in front.
 */
final class Walls {

    interface Sink {
        void showWallpaper(Bitmap bmp, String caption);
    }

    static final long ROTATE_MS = 90_000;           // new photo every 90 s while the home screen is visible
    private static final int MAX_CACHE = 40;         // ~20-40 MB on disk
    private static final long POOL_MAX_AGE = 7L * 24 * 3600 * 1000;
    private static final int MAX_BYTES = 8 * 1024 * 1024;
    private static final String UA = "GlassHome/1.0 (personal Fire TV home screen; wallpaper rotation)";
    private static final String[] CATEGORIES = {
            "Featured_pictures_of_landscapes",
            "Featured_pictures_of_mountains",
            "Featured_pictures_of_lakes",
            "Featured_pictures_of_waterfalls",
            "Featured_pictures_of_forests",
            "Featured_pictures_of_coasts",
    };

    private final Context ctx;
    private final ExecutorService bg;
    private final Handler ui;
    private final Sink sink;
    private final SharedPreferences prefs;
    private final File dir;
    private final Random rnd = new Random();

    private volatile boolean running;
    private volatile boolean busy;
    private volatile String currentName;
    private long lastShown;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            next();
            ui.postDelayed(this, ROTATE_MS);
        }
    };

    Walls(Context ctx, ExecutorService bg, Handler ui, Sink sink) {
        this.ctx = ctx.getApplicationContext();
        this.bg = bg;
        this.ui = ui;
        this.sink = sink;
        this.prefs = this.ctx.getSharedPreferences("walls", Context.MODE_PRIVATE);
        this.dir = new File(this.ctx.getCacheDir(), "walls");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
    }

    /** Start rotating. Shows a photo straight away if none has been shown recently. */
    void start(boolean haveImage) {
        if (running) return;
        running = true;
        long since = System.currentTimeMillis() - lastShown;
        long delay = (!haveImage || since >= ROTATE_MS) ? 0 : ROTATE_MS - since;
        ui.postDelayed(tick, delay);
    }

    void stop() {
        running = false;
        ui.removeCallbacks(tick);
    }

    private void next() {
        if (busy) return;
        busy = true;
        bg.execute(() -> {
            try {
                File f = pick();
                if (f == null || !running) return;
                Bitmap bmp = decode(f);
                if (bmp == null) {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                    return;
                }
                String caption = readCaption(f);
                currentName = f.getName();
                lastShown = System.currentTimeMillis();
                ui.post(() -> {
                    if (running) sink.showWallpaper(bmp, caption);
                });
            } catch (Throwable ignored) {
                // never let a wallpaper problem take the home screen down
            } finally {
                busy = false;
            }
        });
    }

    // ------------------------------------------------------------------ choosing a photo

    private File pick() {
        List<File> cached = cachedFiles();
        boolean online = isOnline();
        boolean wantNew = online && (cached.size() < MAX_CACHE || rnd.nextInt(5) == 0);
        if (wantNew) {
            File fresh = downloadNext(cached);
            if (fresh != null) {
                trim();
                return fresh;
            }
        }
        if (cached.isEmpty()) return null;
        if (cached.size() == 1) return cached.get(0);
        File f;
        do {
            f = cached.get(rnd.nextInt(cached.size()));
        } while (f.getName().equals(currentName));
        return f;
    }

    private List<File> cachedFiles() {
        File[] fs = dir.listFiles((d, n) -> n.endsWith(".jpg"));
        return fs == null ? new ArrayList<>() : new ArrayList<>(Arrays.asList(fs));
    }

    private void trim() {
        List<File> fs = cachedFiles();
        if (fs.size() <= MAX_CACHE) return;
        Collections.sort(fs, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
        for (int i = 0; i < fs.size() - MAX_CACHE; i++) {
            File f = fs.get(i);
            if (f.getName().equals(currentName)) continue;
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            //noinspection ResultOfMethodCallIgnored
            new File(dir, f.getName().replace(".jpg", ".txt")).delete();
        }
    }

    private File downloadNext(List<File> cached) {
        JSONArray pool = pool();
        if (pool == null || pool.length() == 0) return null;
        // Walk the shuffled pool from a rotating offset and take the first photo not already cached.
        int start = prefs.getInt("pool_pos", 0);
        for (int k = 0; k < pool.length(); k++) {
            int idx = (start + k) % pool.length();
            JSONObject o = pool.optJSONObject(idx);
            if (o == null) continue;
            String url = o.optString("u");
            if (url.isEmpty()) continue;
            String name = Integer.toHexString(url.hashCode()) + ".jpg";
            boolean have = false;
            for (File c : cached) if (c.getName().equals(name)) { have = true; break; }
            if (have) continue;
            prefs.edit().putInt("pool_pos", idx + 1).apply();
            File out = new File(dir, name);
            if (download(url, out)) {
                writeCaption(out, o.optString("c"));
                return out;
            }
            return null; // network trouble: fall back to the cache this time
        }
        return null;
    }

    /** Shuffled list of candidate photos, refreshed weekly. */
    private JSONArray pool() {
        long age = System.currentTimeMillis() - prefs.getLong("pool_time", 0);
        String saved = prefs.getString("pool", null);
        if (saved != null && age < POOL_MAX_AGE) {
            try { return new JSONArray(saved); } catch (Exception ignored) { }
        }
        List<JSONObject> items = new ArrayList<>();
        for (String cat : CATEGORIES) {
            try {
                fetchCategory(cat, items);
            } catch (Exception ignored) { }
        }
        if (items.isEmpty()) {
            if (saved != null) {
                try { return new JSONArray(saved); } catch (Exception ignored) { }
            }
            return null;
        }
        Collections.shuffle(items, rnd);
        JSONArray arr = new JSONArray();
        for (JSONObject o : items) arr.put(o);
        prefs.edit().putString("pool", arr.toString())
                .putLong("pool_time", System.currentTimeMillis())
                .putInt("pool_pos", 0).apply();
        return arr;
    }

    private void fetchCategory(String cat, List<JSONObject> out) throws Exception {
        String api = "https://commons.wikimedia.org/w/api.php?action=query&format=json"
                + "&generator=categorymembers&gcmtype=file&gcmlimit=50"
                + "&gcmtitle=" + URLEncoder.encode("Category:" + cat, "UTF-8")
                + "&prop=imageinfo&iiprop=url%7Csize%7Cextmetadata&iiurlwidth=1920"
                + "&iiextmetadatafilter=Artist%7CLicenseShortName%7CObjectName";
        String body = new String(get(api, 2 * 1024 * 1024), StandardCharsets.UTF_8);
        JSONObject q = new JSONObject(body).optJSONObject("query");
        if (q == null) return;
        JSONObject pages = q.optJSONObject("pages");
        if (pages == null) return;
        Iterator<String> it = pages.keys();
        while (it.hasNext()) {
            JSONObject p = pages.optJSONObject(it.next());
            if (p == null) continue;
            JSONArray ii = p.optJSONArray("imageinfo");
            if (ii == null || ii.length() == 0) continue;
            JSONObject info = ii.optJSONObject(0);
            if (info == null) continue;
            String url = info.optString("thumburl", "");
            int w = info.optInt("thumbwidth", info.optInt("width"));
            int h = info.optInt("thumbheight", info.optInt("height"));
            String lower = url.toLowerCase();
            if (url.isEmpty() || h <= 0 || w < 1600) continue;
            if (!(lower.endsWith(".jpg") || lower.endsWith(".jpeg"))) continue;
            float ratio = (float) w / h;
            if (ratio < 1.4f || ratio > 2.2f) continue;   // fits a 16:9 TV without heavy cropping
            JSONObject o = new JSONObject();
            o.put("u", url);
            o.put("c", caption(p.optString("title"), info.optJSONObject("extmetadata")));
            out.add(o);
        }
    }

    private static String caption(String title, JSONObject meta) {
        String name = meta(meta, "ObjectName");
        if (name.isEmpty()) {
            name = title.replaceFirst("^File:", "").replaceFirst("\\.[A-Za-z]+$", "").replace('_', ' ');
        }
        String artist = meta(meta, "Artist");
        String lic = meta(meta, "LicenseShortName");
        StringBuilder sb = new StringBuilder(clip(name, 70));
        if (!artist.isEmpty()) sb.append("  ·  ").append(clip(artist, 40));
        if (!lic.isEmpty()) sb.append("  ·  ").append(lic);
        sb.append("  ·  Wikimedia Commons");
        return sb.toString();
    }

    @SuppressWarnings("deprecation")
    private static String meta(JSONObject meta, String key) {
        if (meta == null) return "";
        JSONObject o = meta.optJSONObject(key);
        if (o == null) return "";
        String v = o.optString("value", "");
        if (v.isEmpty()) return "";
        return Html.fromHtml(v).toString().replaceAll("\\s+", " ").trim();
    }

    private static String clip(String s, int n) {
        return s.length() <= n ? s : s.substring(0, n - 1).trim() + "…";
    }

    // ------------------------------------------------------------------ IO

    private Bitmap decode(File f) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getPath(), o);
        if (o.outWidth <= 0 || o.outHeight <= 0) return null;
        int sample = 1;
        while (o.outWidth / (sample * 2) >= 1920 && o.outHeight / (sample * 2) >= 1080) sample *= 2;
        BitmapFactory.Options d = new BitmapFactory.Options();
        d.inSampleSize = sample;
        d.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(f.getPath(), d);
    }

    private boolean download(String url, File out) {
        File tmp = new File(dir, out.getName() + ".part");
        try {
            byte[] data = get(url, MAX_BYTES);
            try (OutputStream os = new FileOutputStream(tmp)) {
                os.write(data);
            }
            return tmp.renameTo(out);
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
            return false;
        }
    }

    private static byte[] get(String url, int limit) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10_000);
        c.setReadTimeout(20_000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", UA);
        try {
            if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream(256 * 1024);
                byte[] buf = new byte[16 * 1024];
                int n, total = 0;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total > limit) throw new Exception("too big");
                    bos.write(buf, 0, n);
                }
                return bos.toByteArray();
            }
        } finally {
            c.disconnect();
        }
    }

    private void writeCaption(File img, String caption) {
        if (TextUtils.isEmpty(caption)) return;
        try (OutputStream os = new FileOutputStream(new File(dir, img.getName().replace(".jpg", ".txt")))) {
            os.write(caption.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
    }

    private String readCaption(File img) {
        File t = new File(dir, img.getName().replace(".jpg", ".txt"));
        if (!t.exists()) return "";
        try (InputStream in = new java.io.FileInputStream(t)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[1024];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } catch (Throwable e) {
            return "";
        }
    }

    @SuppressWarnings("deprecation")
    private boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return false;
        }
    }
}
